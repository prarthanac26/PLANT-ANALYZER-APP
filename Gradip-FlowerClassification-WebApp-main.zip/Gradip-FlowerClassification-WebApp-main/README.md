![screenshot (1)](https://user-images.githubusercontent.com/54833985/115492155-dcdd4600-a27e-11eb-857a-b7acdb564cbc.png)
# Gradip-FlowerClassification-WebApp
A web application built using gradio for classification of flower images.
Video Explanation on my YouTube channel: https://www.youtube.com/watch?v=aZ4wV4V_p9E
